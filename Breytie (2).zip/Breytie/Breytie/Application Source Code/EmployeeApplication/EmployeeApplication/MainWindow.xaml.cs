﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeeApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            string connectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");


            
            SqlConnection connection = new SqlConnection(connectionString);

            SqlCommand cmd = new SqlCommand("select * from Employees;",connection);

            connection.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            connection.Close();

            dtGrid.DataContext = dt;

        }

        private void AddEmployeeButton_Click(object sender, RoutedEventArgs e)
        {


            Random rnd = new Random();

            string[] alphabet = new string[27];

            alphabet[1] = "a";
            alphabet[2] = "b";
            alphabet[3] = "c";
            alphabet[4] = "d";
            alphabet[5] = "e";
            alphabet[6] = "f";
            alphabet[7] = "g";
            alphabet[8] = "h";
            alphabet[9] = "i";
            alphabet[10] = "j";
            alphabet[11] = "k";
            alphabet[12] = "l";
            alphabet[13] = "m";
            alphabet[14] = "n";
            alphabet[15] = "o";
            alphabet[16] = "p";
            alphabet[17] = "q";
            alphabet[18] = "r";
            alphabet[19] = "s";
            alphabet[20] = "t";
            alphabet[21] = "u";
            alphabet[22] = "v";
            alphabet[23] = "w";
            alphabet[24] = "x";
            alphabet[25] = "y";
            alphabet[26] = "z";

            string answer = "";
            int length = Convert.ToInt32(2);
            int rndCap;
            int rndLetter;

            for (int i = 1; i <= length; i++)
            {
                rndCap = rnd.Next(1, 3);
                rndLetter = rnd.Next(1, 27);
                string tempMem = alphabet[rndLetter];

                if (rndCap == 2)
                {
                    tempMem.ToUpper();
                }
                answer = answer + tempMem;
            }


            //Random 4 Numbers
            int num = new Random().Next(1000, 9999);






            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");

            SqlCommand cmd;


            string EmployeeID;

            EmployeeID = answer.ToUpper();

            string firstname;
            string lastname;
            string contactNumber;
            string emailAddress;
            string date;
            string address;
            string city; ;
            string postalCode;
            string country;
            string skill;
            string years;
            string seniorityRating;

           


            firstname = AddEmployeeFirstName.Text;
            lastname = AddEmployeeLastName.Text;
            contactNumber= AddEmployeeContactNumber.Text;
            emailAddress = AddEmployeeStreetAddress.Text;
            date = Convert.ToString(AddEmployeeDateOfBirth.SelectedDate);
            address = AddEmployeeStreetAddress.Text;
            city = AddEmployeeCity.Text; 
            postalCode = AddEmployeePostalCode.Text;
            country = AddEmployeeCountry.Text;
            skill = AddEmployeeSkill.Text;
            years = AddEmployeeYearsExp.Text;


           



            //id++;
            cmd = new SqlCommand("INSERT INTO [dbo].[Employees](EmployeeID, FirstName, LastName, Contact, Email, DateOfBirth, Street, City, PostalCode, Country)" +
                 "values(@EmployeeID, @FirstName, @LastName, @Contact, @Email, @DateOfBirth, @Street, @City, @PostalCode, @Country);", conn);
            //   cmd.Parameters.AddWithValue("@Id", id);
            cmd.Parameters.AddWithValue("@EmployeeID", EmployeeID + num);
            cmd.Parameters.AddWithValue("@FirstName", firstname);
            cmd.Parameters.AddWithValue("@LastName", lastname);
            cmd.Parameters.AddWithValue("@Contact", contactNumber);
            cmd.Parameters.AddWithValue("@Email", emailAddress);
            cmd.Parameters.AddWithValue("@DateOfBirth", date);
            cmd.Parameters.AddWithValue("@Street", address);
            cmd.Parameters.AddWithValue("@City", city);
            cmd.Parameters.AddWithValue("@PostalCode", postalCode);
            cmd.Parameters.AddWithValue("@Country", country);

        
            conn.Open();
            cmd.ExecuteNonQuery();

            //Comfirmation Message
            MessageBox.Show("Successful");
            conn.Close();
        }

        private void SearchBTN_Click(object sender, RoutedEventArgs e)
        {
            string connectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");


            string EMP = IDTextbox.Text;
            SqlConnection connection = new SqlConnection(connectionString);

            SqlCommand cmd = new SqlCommand("select * from Employees where EmployeeID='"+EMP+"';", connection);
           

            connection.Open();
            DataTable dt2 = new DataTable();
            dt2.Load(cmd.ExecuteReader());
            connection.Close();

            dtGrid2.DataContext = dt2;
        }

        private void EditFirstNameBTN_Click(object sender, RoutedEventArgs e)
        {
          

            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");

            SqlCommand cmd;


            string EMP = IDTextbox.Text;
            string Value = EditEmployeeFirstName.Text;

            //id++;
            cmd = new SqlCommand("UPDATE Employees SET FirstName = '"+Value+"' WHERE EmployeeID = '"+EMP+"';", conn);
        

            conn.Open();
            cmd.ExecuteNonQuery();

            //Comfirmation Message
            MessageBox.Show("Successful");
            conn.Close();
        }

        private void EditLastNameBTN_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");

            SqlCommand cmd;


            string EMP = IDTextbox.Text;
            string Value = EditEmployeeLastName.Text;

            //id++;
            cmd = new SqlCommand("UPDATE Employees SET LastName = '" + Value + "' WHERE EmployeeID = '" + EMP + "';", conn);


            conn.Open();
            cmd.ExecuteNonQuery();

            //Comfirmation Message
            MessageBox.Show("Successful");
            conn.Close();
        }

        private void EditContactBTN_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");

            SqlCommand cmd;


            string EMP = IDTextbox.Text;
            string Value = EditEmployeeContactNumber.Text;

            //id++;
            cmd = new SqlCommand("UPDATE Employees SET Contact = '" + Value + "' WHERE EmployeeID = '" + EMP + "';", conn);


            conn.Open();
            cmd.ExecuteNonQuery();

            //Comfirmation Message
            MessageBox.Show("Successful");
            conn.Close();
        }

        private void EditEmailBTN_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");

            SqlCommand cmd;


            string EMP = IDTextbox.Text;
            string Value = EditEmployeeEmail.Text;

            //id++;
            cmd = new SqlCommand("UPDATE Employees SET Email = '" + Value + "' WHERE EmployeeID = '" + EMP + "';", conn);


            conn.Open();
            cmd.ExecuteNonQuery();

            //Comfirmation Message
            MessageBox.Show("Successful");
            conn.Close();
        }

        private void EditStreetBTN_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");

            SqlCommand cmd;


            string EMP = IDTextbox.Text;
            string Value = EditEmployeeStreetAddress.Text;

            //id++;
            cmd = new SqlCommand("UPDATE Employees SET Street = '" + Value + "' WHERE EmployeeID = '" + EMP + "';", conn);


            conn.Open();
            cmd.ExecuteNonQuery();

            //Comfirmation Message
            MessageBox.Show("Successful");
            conn.Close();
        }

        private void EditCityBTN_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");

            SqlCommand cmd;


            string EMP = IDTextbox.Text;
            string Value = EditEmployeeCity.Text;

            //id++;
            cmd = new SqlCommand("UPDATE Employees SET City = '" + Value + "' WHERE EmployeeID = '" + EMP + "';", conn);


            conn.Open();
            cmd.ExecuteNonQuery();

            //Comfirmation Message
            MessageBox.Show("Successful");
            conn.Close();

        }

        private void EditPostalBTN_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");

            SqlCommand cmd;


            string EMP = IDTextbox.Text;
            string Value = EditEmployeePostalCode.Text;

            //id++;
            cmd = new SqlCommand("UPDATE Employees SET PostalCode = '" + Value + "' WHERE EmployeeID = '" + EMP + "';", conn);


            conn.Open();
            cmd.ExecuteNonQuery();

            //Comfirmation Message
            MessageBox.Show("Successful");
            conn.Close();
        }

        private void EditCountryBTN_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");

            SqlCommand cmd;


            string EMP = IDTextbox.Text;
            string Value = EditEmployeeCountry.Text;

            //id++;
            cmd = new SqlCommand("UPDATE Employees SET Country = '" + Value + "' WHERE EmployeeID = '" + EMP + "';", conn);


            conn.Open();
            cmd.ExecuteNonQuery();

            //Comfirmation Message
            MessageBox.Show("Successful");
            conn.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");

            SqlCommand cmd;


            string EMP = IDTextbox.Text;
            string Value = Convert.ToString(EditEmployeeDateOfBirth.SelectedDate);

            //id++;
            cmd = new SqlCommand("UPDATE Employees SET DateOfBirth = '" + Value + "' WHERE EmployeeID = '" + EMP + "';", conn);


            conn.Open();
            cmd.ExecuteNonQuery();

            //Comfirmation Message
            MessageBox.Show("Successful");
            conn.Close();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            string connectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");



            SqlConnection connection = new SqlConnection(connectionString);

            SqlCommand cmd = new SqlCommand("select * from Employees;", connection);

            connection.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            connection.Close();

            dtGrid.DataContext = dt;
        }

        private void SearchBTN2_Click(object sender, RoutedEventArgs e)
        {
            string connectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");


            string EMP = IDTextbox2.Text;
            SqlConnection connection = new SqlConnection(connectionString);

            SqlCommand cmd = new SqlCommand("select * from Employees where EmployeeID='" + EMP + "';", connection);


            connection.Open();
            DataTable dt3 = new DataTable();
            dt3.Load(cmd.ExecuteReader());
            connection.Close();

            dtGrid3.DataContext = dt3;
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {


            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");

            SqlCommand cmd;


            string EMP = IDTextbox2.Text;


            cmd = new SqlCommand("DELETE FROM Employees WHERE EmployeeID ='" + EMP + "';", conn);


            conn.Open();
            cmd.ExecuteNonQuery();

            //Comfirmation Message
            MessageBox.Show("Successful");
            conn.Close();
        }

        private void ASC_Click(object sender, RoutedEventArgs e)
        {
            string connectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");



            SqlConnection connection = new SqlConnection(connectionString);

            SqlCommand cmd = new SqlCommand("SELECT FirstName,DateOfBirth FROM Employees ORDER BY DateOfBirth;", connection);

            connection.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            connection.Close();

            dtGrid.DataContext = dt;
        }

        
        private void SearchBTN3_Click(object sender, RoutedEventArgs e)
        {
            string connectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");


            string EMP = IDTextbox3.Text;
            SqlConnection connection = new SqlConnection(connectionString);

            SqlCommand cmd = new SqlCommand("select * from Employees where EmployeeID='" + EMP + "';", connection);


            connection.Open();
            DataTable dt4 = new DataTable();
            dt4.Load(cmd.ExecuteReader());
            connection.Close();

            dtGrid4.DataContext = dt4;





            /////////////////////////////
            ///



            string connectionString2 = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");


            

            SqlConnection connection1 = new SqlConnection(connectionString2);

            SqlCommand cmd2 = new SqlCommand("select * from Skills where EmployeeID='" + EMP + "';", connection1);
            connection1.Open();
            DataTable dt5 = new DataTable();
            dt5.Load(cmd2.ExecuteReader());
            connection1.Close();

            dtGrid5.DataContext = dt5;
        }

        

        private void AddSkillBtn_Click_1(object sender, RoutedEventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Breytie\Downloads\Breytie\Breytie\Application Source Code\EmployeeApplication\EmployeeApplication\Database2.mdf;Integrated Security=True");

            SqlCommand cmd;



            string SkillName, YearsExperience, SeniorityRating;



            SkillName = AddEmployeeSkill.Text;
            YearsExperience = AddEmployeeYearsExp.Text;

            

            string EMP = IDTextbox3.Text;

            bool Option1 = (bool)CB1.IsChecked;
            bool Option2 = (bool)CB2.IsChecked;
            bool Option3 = (bool)CB3.IsChecked;

            SeniorityRating = "High";
            if (Option1 == true)
            {
                SeniorityRating = "High";
            }
            if (Option2 == true)
            {
                SeniorityRating = "Medium";
            }
            if (Option3 == true)
            {
                SeniorityRating = "Low";
            }
            //id++;
            cmd = new SqlCommand("INSERT INTO [dbo].[Skills](SkillName,YearsExperience,SeniorityRating, EmployeeID)" +
                 "values(@SkillName,@YearsExperience,@SeniorityRating, @EmployeeID);", conn);
            //   cmd.Parameters.AddWithValue("@Id", id);
            cmd.Parameters.AddWithValue("@SkillName", SkillName);
            cmd.Parameters.AddWithValue("@YearsExperience", YearsExperience);
            cmd.Parameters.AddWithValue("@SeniorityRating", SeniorityRating);
            cmd.Parameters.AddWithValue("@EmployeeID", EMP);

            conn.Open();
            cmd.ExecuteNonQuery();

            //Comfirmation Message
            MessageBox.Show("Successful");
            conn.Close();
        }
    }
}
