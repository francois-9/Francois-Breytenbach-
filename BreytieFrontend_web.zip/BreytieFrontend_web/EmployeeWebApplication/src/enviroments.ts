export const environment = {
  baseurl: 'https://localhost:7179'
}
