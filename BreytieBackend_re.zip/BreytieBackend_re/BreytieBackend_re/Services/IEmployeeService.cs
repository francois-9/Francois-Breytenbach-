﻿using BreytieBackend_re.Models;

namespace BreytieBackend_re.Services
{
    public interface IEmployeeService
    {
        Task<IEnumerable<Employees>> GetAllEmployees();
        Task<Employees> GetEmployeeById(string id);
        Task<Employees> CreateEmployee(Employees newEmployee);
        Task UpdateEmployee(Employees employeeToUpdate);
        Task DeleteEmployee(string id);
        string generateEmpID();
    }
}
