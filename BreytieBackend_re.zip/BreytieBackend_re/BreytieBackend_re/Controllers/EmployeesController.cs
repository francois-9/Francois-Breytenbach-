﻿using BreytieBackend_re.Models;
using BreytieBackend_re.Services;
using Microsoft.AspNetCore.Mvc;

namespace BreytieBackend_re.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmployeesController : ControllerBase
    {
        private readonly IEmployeeService _employeeService;

        public EmployeesController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        [HttpGet]
        public async Task<IEnumerable<Employees>> Get()
        {
            return await _employeeService.GetAllEmployees();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Employees>> Get(string id)
        {
            var employee = await _employeeService.GetEmployeeById(id);
            if (employee == null)
            {
                return NotFound();
            }
            return employee;
        }

        [HttpPost]
        public async Task<ActionResult<Employees>> Post(Employees newEmployee)
        {
            newEmployee.EmployeeID = _employeeService.generateEmpID();
            var employee = await _employeeService.CreateEmployee(newEmployee);
            return CreatedAtAction(nameof(Get), new { id = employee.EmployeeID }, employee);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(string id, Employees updatedEmployee)
        {
            if (id != updatedEmployee.EmployeeID)
            {
                return BadRequest();
            }
            await _employeeService.UpdateEmployee(updatedEmployee);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            await _employeeService.DeleteEmployee(id);
            return NoContent();
        }

    }
}
