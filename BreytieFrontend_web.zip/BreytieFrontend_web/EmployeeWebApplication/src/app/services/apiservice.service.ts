import { Injectable } from '@angular/core';
import { environment } from '../../enviroments';
import { Observable, Subject, tap } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {
  baseurl = environment.baseurl
  private employees: any[] = [];
  private updatedEmployees = new Subject<any[]>();
  constructor(private http: HttpClient) { }

  fetchEmployees() {
    console.log(this.baseurl + '/Employees');
    this.http
      .get<any[]>(this.baseurl + '/Employees')
      .subscribe((response) => {
        console.log(response);
        this.employees = response;
        console.log(this.employees);
        this.updatedEmployees.next([...this.employees]);
      });
  }

  addNewEmployee(Employee: any): Observable<any> {
    console.log(this.baseurl + '/Employees');
    return this.http.post(this.baseurl + '/Employees', Employee).pipe(
      tap((response) => {
        console.log(response);
        this.fetchEmployees();
      })
    );
  }

  deleteEmployee(employeeID: string): Observable<any> {
    return this.http.delete(this.baseurl + '/Employees/' + employeeID).pipe(
      tap((response) => {
        console.log(response);
        this.fetchEmployees();
      })
    );
  }

  updateEmployee(id: string, updatedEmployee: any): Observable<any> {
    return this.http.put(this.baseurl + '/Employees/' + id, updatedEmployee).pipe(
      tap((response) => {
        console.log(response);
        this.fetchEmployees();
      })
    );
  }


  getEmployeeListiner() {
    return this.updatedEmployees.asObservable();
  }


  private currentEmployee: any;

setCurrentEmployee(employee: any): void {
  this.currentEmployee = employee;
}

getCurrentEmployee(): any {
  return this.currentEmployee;
}


}
