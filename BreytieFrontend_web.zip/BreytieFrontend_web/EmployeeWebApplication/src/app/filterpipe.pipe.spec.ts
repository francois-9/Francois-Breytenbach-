import { FilterpipePipe } from './filterpipe.pipe';

describe('FilterpipePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterpipePipe();
    expect(pipe).toBeTruthy();
  });
});
