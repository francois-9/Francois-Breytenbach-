﻿using BreytieBackend_re.Models;
using Microsoft.EntityFrameworkCore;

namespace BreytieBackend_re.Data
{
    public class BreytieDatabaseContext:DbContext
    {
        public BreytieDatabaseContext(DbContextOptions<BreytieDatabaseContext> options)
       : base(options)
        {
        }
        public DbSet<Employees> Employees { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employees>()
                .HasKey(e => e.EmployeeID);
            // Other model configurations...
        }
    }
}
