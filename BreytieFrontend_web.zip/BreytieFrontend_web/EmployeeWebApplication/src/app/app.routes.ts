import { Routes } from '@angular/router';
import { ViewComponent } from './features/view/view.component';
import { AddComponent } from './features/add/add.component';
import { EditComponent } from './features/edit/edit.component';

export const routes: Routes = [
  { path: '', component: ViewComponent },
  { path: 'add', component: AddComponent },
  { path: 'edit', component: EditComponent },
  { path: 'edit/:id', component: EditComponent }
];
