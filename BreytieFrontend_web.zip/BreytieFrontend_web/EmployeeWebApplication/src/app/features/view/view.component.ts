import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule, DatePipe } from '@angular/common';
import { FilterpipePipe } from '../../filterpipe.pipe';
import { ApiserviceService } from '../../services/apiservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view',
  standalone: true,
  imports: [FormsModule,DatePipe,FilterpipePipe,CommonModule],
  templateUrl: './view.component.html',
  styleUrl: './view.component.css'
})
export class ViewComponent {
  searchDate: string='';
  searchText = '';
  searchField = 'FirstName';
  employees:any[] = [
    // Your employees data here
  ];

  constructor(private _apiService:ApiserviceService,private router: Router) {
    this._apiService.fetchEmployees();
    this._apiService.getEmployeeListiner().subscribe({
      next: (result) => {
        this.employees = result;
        console.log(this.employees)
      },
      //Display error message on the console.
      error: (error) => {
        /* console.error(
          'An error occurred, cannot retrieve Positions from API:',
          error
        ); */
      },
    });
  }

  onSearchFieldChange() {
    localStorage.setItem('searchField', this.searchField);
  }

  ngOnInit() {
    const storedSearchField = localStorage.getItem('searchField');
    if (storedSearchField) {
      this.searchField = storedSearchField;
    }
  }

  deleteEmployee(employeeID: string): void {
    this._apiService.deleteEmployee(employeeID).subscribe(response => {
      console.log("Employee deleted successfully");
    }, error => {
      console.error("Error deleting employee", error);
    });
  }

  editEmployee(employee: any): void {
    this._apiService.setCurrentEmployee(employee);
    this.router.navigate(['/edit', employee.employeeID]);
  }

}
