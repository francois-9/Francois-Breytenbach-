import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterpipe',
  standalone: true
})
export class FilterpipePipe implements PipeTransform {

  transform(items: any[], searchText: string, searchField: string): any[] {
    if (!items) return [];
    if (!searchText) return items;

    searchText = searchText.toLowerCase();

    return items.filter(it => {
      return it[searchField] && typeof it[searchField] === 'string' && it[searchField].toLowerCase().includes(searchText);
    });
  }

}
