﻿using BreytieBackend_re.Data;
using BreytieBackend_re.Models;
using Microsoft.EntityFrameworkCore;

namespace BreytieBackend_re.Services
{
    public class EmployeeService:IEmployeeService
    {
        private readonly BreytieDatabaseContext _context;

        public EmployeeService(BreytieDatabaseContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Employees>> GetAllEmployees()
        {
            return await _context.Employees.ToListAsync();
        }

        public async Task<Employees> GetEmployeeById(string id)
        {
            return await _context.Employees.FindAsync(id);
        }

        public async Task<Employees> CreateEmployee(Employees newEmployee)
        {
            _context.Employees.Add(newEmployee);
            await _context.SaveChangesAsync();
            return newEmployee;
        }

        public async Task UpdateEmployee(Employees employeeToUpdate)
        {
            _context.Entry(employeeToUpdate).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteEmployee(string id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee != null)
            {
                _context.Employees.Remove(employee);
                await _context.SaveChangesAsync();
            }
        }

        public string generateEmpID() {
            Random rnd = new Random();
            string[] alphabet = new string[27]
            {
        "", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
        "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"
            };

            string answer = "";
            int length = 2;
            int rndCap;
            int rndLetter;

            for (int i = 1; i <= length; i++)
            {
                rndCap = rnd.Next(1, 3);
                rndLetter = rnd.Next(1, 27);
                string tempMem = alphabet[rndLetter];

                if (rndCap == 2)
                {
                    tempMem = tempMem.ToUpper();
                }
                answer = answer + tempMem;
            }

            //Random 4 Numbers
            int num = rnd.Next(1000, 9999);

            return answer.ToUpper() + num;
        }


    }
}
